# Privacy Policy

## Personal or Sensitive User Data

目前,我们不会收集任何用户信息。

:-)

## Use of Permissions


| 权限          | 用途说明                                        |
| ------------- | ----------------------------------------------- |
| storage       | 用于存储配置信息,例如使用的图床                 |
| contextMenus  | 用于右键菜单上传,在页面上右键选项对图片进行上传 |
| notifications | 用于通知状态,如右键上传/拖拽上传的完成或失败    |

### 我们保证存储的任何信息,不会被上传,不会被共享